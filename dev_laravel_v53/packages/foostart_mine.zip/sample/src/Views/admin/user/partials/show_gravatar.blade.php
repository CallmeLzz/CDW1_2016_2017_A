<div class="row">
    <div class="col-md-6">
        <h4><i class="fa fa-picture-o"></i> Avatar</h4>
        <div class="profile-avatar">
            <img src="{!! $user_profile->presenter()->avatar(170) !!}">
        </div>
    </div>
    <div class="col-md-6">
    </div>
</div>
 