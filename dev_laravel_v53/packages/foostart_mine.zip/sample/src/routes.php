<?php

Route::get('sample',  'Foostart\Sample\Controllers\SampleController@index');
Route::get('sampledata',  'Foostart\Sample\Controllers\SampleController@getData');

Route::get('sampleadmin', [
            "as"   => "user.admin.login",
            "uses" => 'Foostart\Sample\Controllers\AdminController@index'
    ]);
Route::get('dashboard', [
            "as"   => "user.admin.dashboard",
            "uses" => 'Foostart\Sample\Controllers\DashboardController@base'
    ]);