<?php
return [

    'name_min_length' => 50,
    'name_max_length' => 155
];